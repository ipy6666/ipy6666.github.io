<html>
  <head>
    <meta charset="utf-8">
 
<meta http-equiv="refresh" content="0;URL=https://www.izm.best/auth/login"> 


  </head>
  <body>
    正在跳转最新网址:
    <a href="javascript:;" target="_blank">
      <span style="font-size:32px;">
     https://www.izm.best
        </span>
        </a>
  </body>
</html>
